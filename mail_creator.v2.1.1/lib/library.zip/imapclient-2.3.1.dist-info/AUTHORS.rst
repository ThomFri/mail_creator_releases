IMAPClient was created by Menno Finlay-Smits <inbox@menno.io>. The
project is now maintained by Nicolas Le Manchet and Menno
Finlay-Smits.

Many thanks go to the following people for their help with this
project:

- Maxime Lorant
- Mathieu Agopian
- Chris Arndt
- Jp Calderone
- John Louis del Rosario
- Dave Eckhardt
- Eben Freeman
- Helder Guerreiro
- Mark Hammond
- Johannes Heckel
- Thomas Jost
- Lukasz Mierzwa
- Naveen Nathan
- Brian Neal
- Phil Peterson
- Aviv Salem
- Andrew Scheller
- Thomas Steinacher
- Zac Witte
- Hans-Peter Jansen
- Carson Ip
- Jonny Hatch
- Jasper Spaans
- Fabio Manganiello
- Samir M
- Devin Bayer
- Mantas Mikulėnas
- zrose584
- Michał Górny
- François Deppierraz
- Jasper Spaans
- Boni Lindsley 
- Tobias Kölling
- pinoatrome
- Shoaib Ahmed 

